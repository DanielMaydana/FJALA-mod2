#pragma once

struct list_info
{
    long long first = -1;
    long long last = -1;
};