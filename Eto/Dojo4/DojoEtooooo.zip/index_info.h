#pragma once

struct index_info
{
    long long data_pos = -1;
    long long next = -1;
};