#include <stdio.h> 
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

int main()
{
    // puts("Enter 2 numbers");
    // int a = 0, b = 0;
    // size_t x = scanf("%d %d", &a, &b);
    // printf("Validity: %lu\n", x); // informs how many parameters it was able to scan
    // printf("The result is %d\n", a + b);

    // ------------------------------
    
    // puts("Enter 3 numbers");
    // int a2 = 0, b2 = 0, c2 = 0;
    // scanf("%d : %d : %d", &a2, &b2, &c2);
    // printf("%d\n", a2 + b2 + c2);

    // ------------------------------

    // puts("Enter name");
    // char name[200];
    // fgets(name, 200, stdin); // to read an entire char until the null character
    // puts(name);

    // ------------------------------

    // const char* buffer = "10:20:30";
    // int a = 0, b =0, c = 0;

    // sscanf(buffer, "%d:%d:%d", &a, &b, &c); // for reading chars in the memory
    // printf("%d\n", a + b + c);

    // const char* pi = "3.141592";
    // double pid;

    // sscanf(pi, "%lf", &pid);
    // printf("%g\n", pid * 2);

    // ------------------------------

    
}